# Independent existing-checkpoint readout prelaunch review

Decision: **PASS after two material fixes**, conditional on refreshing final draft/source hashes and prospectively freezing this exact implementation and bounded reservation. No GPU, network, model/tokenizer inference, training, agents or source edits were performed. Offline JSON/hash inspection and pure integer geometry checks only; this review file is the sole mutation.

## Findings resolved

1. **Cloud/local headroom serialization mismatch.** The original worker compared Linux cloud result bytes against the Windows local raw SHA2d4f… . Local bytes contain2224CRLF sequences while the cloud writer uses LF; the cloud guard would have aborted before inference. Changed lines now verify remote expected LF bytes separately and then the same canonical parsed-JSON hash. Runner retains the unchanged local raw hash and independently reconstructs both canonical and expected LF bindings. Prior artifacts are untouched. Expected remote LF SHA is7225b3d4f76ea42b671467a78b21648a5e4c1b0cd03e45493cf1c40a70bd305a. Canonical SHA: `e347b5af9326cd9b746e7f96bc23e993d2b932d62f07ebf7dc8f2ae47bc1674d`.
2. **Ambiguous labels incorrectly sufficient for specificity.** Original analysis checked treatment ambiguity but allowed an ambiguous incorrect baseline/donor to count as confidently wrong. Changed analysis now requires unambiguous incorrect A,B and matched donor, unambiguous correct/nonhallucinated treatment, and exports separate automatic/privileged ambiguity flags. Stable labels are preserved. No rescue may be certified from an unresolved donor/baseline judgment.

Changed lines for both fixes were independently re-read. No remaining material static blocker was found.

## Implementation matched to scientific decision

Read scientific decision,protocol,draft,readout_candidates.py,worker,runner,analysis and connector.pack_prompt. Six arms in each of two views use the pinned existing full-best checkpoint; no optimizer/training path exists. Before/after checkpoint bytes and adapter state tensors are checked. Frozen eval/inference mode and pinned models match the earlier setup. Generation uses the cached ASR scaffold and genuine question,answer=None,greedy48tokens,use_cache=True. Gold-answer NLL occurs only afterward in a separate use_cache=False forward. No publisher reference or answer enters candidate construction,routing or generation.

A is K0text. B uses the original cached DTW tensors and actual posterior metadata. Clean D is the exact Bpayload, while noisy D activates the reference-free grid only for an empty candidate set. C provides four reported-window bins[145,160),[160,175),[175,190),[190,205),filling four slots; it is privileged uncertain-window input, not verified whole-phrase geometry. Grid D gives35windows over684valid frames,34full20frame windows plus final[680,684),preserving all frames. Pure integer checks reproduce these values. At most four slots are selected chronologically.

New windows have zero uncertainty and availability=false. Padded final-window frames are zero/masked; valid-duration bounds prevent padded30second frames becoming candidates. The grid builder accepts only encoder states/valid frame count/windows,with no question/reference/answer. Same waveform PCM16/32768scaling and original eager frozen Whisper encoder are used; no ASR regeneration occurs. Existing DTW acoustic tensors remain cached. A fresh encoder pass for new geometry introduces a distribution difference that is explicit and must not be assumed equivalent to old features bitwise.

Both donor controls preserve recipient geometry,masks,actual U/availability,scaffold and question. C uses identical bins over donor frames. Clean fallback donor replacement retains cached posterior metadata; noisy fallback donor uses the same35grid windows with Uunavailable. No temporal resampling is needed because donor1868matches duration/condition. Donor content can change pooled content and rankings; selection is intentionally not held fixed,so this is a complete-interface audio consistency control.

## Inventory, safeguards and analysis

Only224historical manifest IDs are inspected,with manifest bytes bound. Existing feature tensors load on CPU for metadata; missing rows are retained as missing and never regenerated. Exported cache byte hashes,current transcripts,masks/counts,filtered span windows and physical coverage distinguish present-empty/present-nonempty/missing. Expected min(4,valid spans) is clearly labeled expected,not observed training selection; actual old selected indices exist only where prior dev outputs supply them. Analysis attaches source IDs via the manifest and separates train/dev/condition and observed-cache denominators. No population prevalence should use all224as if every cache were present.

K0noisy B=A and nonempty clean D=B guards compare prompt hashes,selected indices and generated token IDs; A/Balso compare against archived headroom outputs. Guard mismatch defers interpretation and does not trigger a rerun. Runner claims the local run before spawn,uses immutable source/input/budget checks,bounded resources and no retries. Raw outputs/failures/spelling ambiguities must remain visible.

Analysis preserves NLL/EM separately from semantic correctness and audio specificity. Availability requires noisy35grid candidates/684frame union/four slots; finite memory and raw answer inspection remain runtime requirements. NLL,coverage or norm shifts alone cannot certify a supported answer rescue. Microtimings are descriptive,not an end-to-end benchmark. Inventory coverage counts reflect valid frame geometry and must not be confused with semantic target coverage.

## Scope and final bindings

A positive source-specific rescue would concern this checkpoint,reported geometry and fixed donor on one selected historical source. A failure would not establish general acoustic unrecoverability or rule out a separately trained readout. Neither outcome grants broader training/fresh-test GO. Final freeze/reservation remain root-owned; any changed source must be rehashed after this review.

Reviewed source SHA256 values:

- `readout_candidates.py`: `e8c8919f1b5fec820c72652c2c960c62955e7ad99458ff32b383da87e931b819`
- `readout_worker.py`: `ef1b43eea3dcc437e40e1ea3e4736137551ec1dc5b115dc94023ef6765400c70`
- `readout_runner.py`: `946651ba1029f6f74f860dda958f97017d23486e3fbb56e6acf719705f36979c`
- `readout_analysis.py`: `73d26253d49695baba9c93967a9d617f84c7bd36bf4c53e6621e82d48a75a4cf`
- `prepare_readout.py`: `e4c00e639ab3380b9445393f23cdbc8a355dd2dac77960d50389f72fe06cbc92`
- `connector.py`: `39803bc3e46f4db213a911dae6438a8eb8d908f95c2d2efc36238fedf24e68db`
- `readout_scientific_decision.md`: `d340393968056908872d7d35581686d55282239e9d4ed7504d6404bfdd2dfa96`
- `readout_protocol_draft.md`: `2b45988dc9279595c776988e70f299fa5655006409a9fe91d0211ed388670d8a`
