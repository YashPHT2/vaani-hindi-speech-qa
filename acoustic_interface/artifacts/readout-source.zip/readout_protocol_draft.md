# Existing-checkpoint readout and fallback: prospective draft

Status: implementation/protocol review, no model run or new training. This is
the small historical-development experiment requested in the latest assessment.
Original candidate/score/QA freezes remain immutable; fresh100 stays sealed.

## Question and scope

Separate candidate availability from existing-interface utility. One primary
source1806, clean/noise10dB views; twelve responses across six matched arms.
The sixth arm is a second geometry-matched wrong-audio control, not a new method.
Do not report these repeated views as independent sources or a generalization
estimate. No parameters are updated; no alignment repair or K expansion occurs.

Pinned existing full-best adapter byteSHA
8474698e8123d52e4ea96e310691062e49ce76f62d9e924d1976102ffbad2345;
same Qwen2.5-1.5B revision989aa7980e4cf806f80c7fef2b1adb7bc71aa306,
same prompt function, supplied question, cached hard ASR scaffold, greedy48token
cap and seed17. Freeze all source/input/code hashes before inference.

## Arms (proposed pending scientific-lead decision)

| Arm | Memory candidates | Matched interpretation |
|---|---|---|
| A | K0, no added acoustic memory | Existing transcript-only baseline |
| B | Existing DTW candidates, unchanged full-checkpoint selector | Existing adapter baseline |
| C | Reported privileged interval2.9–4.1s, four contiguous equal encoder-frame bins | Existing readout with supplied interval |
| D | Preserve B when candidates exist; otherwise fixed20frame windows with finalpartial retained | Reference-free fallback-only policy |
| E_oracle | C's geometry over frozen donor1868 | C-matched wrong-audio control |
| E_fallback | D's actual geometry over the donor, keeping actual uncertainty metadata | D-matched wrong-audio control |

All use at most four vectors and the same existing question-conditioned
pooling/scorer/projection/gates. C is privileged reported-window input, not a
deployment mechanism or verified whole-phrase oracle: fullphraseextent remains
false. Donor and source durations match13.68s; no temporal resampling is needed.

Grid construction accepts only full frozen encoder states and valid-duration
frame counts, not question, transcript, reference or answers. Frames are20ms;
20frame nonoverlapping windows span the valid duration, retaining any nonempty
last window. At13.68s/684frames, this gives35candidates. Grid/oracle uncertainty
values are zero with availability=false. They are genuinely unavailable, not
estimated confidences. This input distribution differs from much of training.

The original DTW pathway retains its stored features/uncertainty. Clean D must
reuse B exactly because B already has candidates. For noisy B, K0 is retained;
D is allowed access to new frame windows. Wrong-audio conditions replace frame
content with donor content under identical candidate geometry, keeping scaffold
and routing metadata fixed to isolate content as far as that control permits.

## Measurements and guards

Record candidate/selected counts, bounds and physical frame coverage, target
overlap, uncertainty availability, gates, memory norms and reference Qwen token
embedding norms. Positive overlap is not semantic retention; contextual frame
representations further complicate localization. No norm repair is introduced.

Score generated correctness and unsupported assertions with the existing
publisher-evidence rubric, independently reviewed and explicitly model-judged.
Report exactmatch separately and retain spelling ambiguity. Reuse stable
source/question/answer hashes for prior identical judgments. Count rescues and
regressions against A and B, retaining the two-view/full denominator.

Teacher-forced answer NLL is a separate scoring forward; generation receives
no gold answer or publisher transcript. A useful NLL shift without generated
answer benefit does not establish H2. Capture raw responses, finish reasons,
tokens, generation timing and peak memory. These microtimings are not a new
100-source latency/RTF benchmark.

Guard A against prior headroom B and new B against prior headroom D. Flag
baseline-output mismatches and prohibit automatic reruns. Check D=B exactly
in the nonempty clean case. Check checkpoint bytes before/after and frozen eval
state. A mismatch requires review before scientific interpretation.

## Broader existing-cache audit

Within the same bounded job, inspect only the224allowlisted historical manifest
view IDs. Export available/missing status for every view. For existing trusted
feature tensors, record cache byteSHA, current transcript, candidate spans and
durations, valid-frame count, physical union coverage and masks. Do not read
unallowlisted cache IDs, regenerate missing features or inspect fresh100.

This is metadata/tensor inspection, not GPU model inference or training on the
historical pool. Returned identities will establish source overlap for the
archived12empty views and permit source/condition-stratified descriptive ASR
error analysis. Distinguish missing cache from an observed empty candidate set.
Keep train/dev and availability denominators explicit; legacy ASR is auxiliary
and must not silently substitute for current cache transcripts.

## Decision boundaries and resources

H1 availability requires valid reference-free candidates on the previously
empty view, produced without reference content. It does not imply H2 utility.
H2 evidence requires meaningful generated answer changes and examination of
matched wrong audio, not only likelihood. A failed C limits this checkpoint
under a reported-window distribution; it does not rule out an oracle-trained
or better-aligned readout. No automatic training/fresh-evaluation GO follows.

One A10, CPU2/RAM16GiB,600sfunction/300sstartup/120squeue, idle2s, no retries.
Proposed USD1reservation, previous conservative boundUSD0.63168344; all prior
reservations plus this and protectedUSD3sumUSD15, within existingUSD30 ceiling.
Check current gross metering and zero other GPU tasks before launch. Stop after
the frozen run and one independent integrity/semantic review; no score-driven
geometry, prompt, checkpoint or generation search.
