# Independent alignment prelaunch code review

Static review passed for the prospective CE versus CE+KL package. The initial worker used the scalar preflight normalizer and omitted the teacher adequacy stop. The final code imports the frozen repository normalizer and returns a typed stop before either fit when fewer than four distinct answerable training sources qualify. Eligible unanswerable sources are reported separately. A detached teacher cache is generated on training sources only and bound to exact target IDs and tensor hashes. The final worker verifies those hashes and requires a finite positive KL-only connector gradient and nonzero parameter updates in both arms.

A synthetic CPU test with unequal prompt lengths checked the causal answer offset, target ordinal and EOS alignment, FP32 teacher-to-student full-vocabulary KL, temperature-squared weighting and student gradient. The worker asserts exactly one assistant end token. Both arms reload the same checkpoint and buffers, use fresh identical AdamW settings and consume the same four shuffled passes over all 64 training views. The experimental objective averages CE and the weighted KL term over all eight views, including views that contribute zero KL. Each arm uses the endpoint at update 32. The worker checks the starting checkpoint, frozen backbone parameter versions and gradients, preserved uncertainty buffers, and checkpoint state through evaluation.

The 86 waveform and existing cache bindings and the source-paired donor map were checked against the historical manifest and prior inventory. Donors are chosen from another source in the same condition. Their encoder frames are resampled to recipient duration and substituted while preserving geometry, masks, uncertainty metadata, question and ASR scaffold. Development generation consumes the ASR scaffold, genuine question and current memory. Separate target scoring follows generation. Source 1806 is excluded. The paired outcome code retains all 22 development views and requires both reconciled and strict gates. A CPU fixture passed with two qualifying sources and failed when one corresponding donor failure was ambiguous.

The runner's normal entrypoint requires a reviewed freeze, a distinct explicit user authorization record bound to its byte hash, and a ledger entry bound to the authorization hash before spawn. In-memory checks rejected absent approval, a stale freeze hash and an authorization hash mismatch in the ledger. At review time the local workspace had no alignment authorization, allocation, job, launch configuration or result record. The runner claims one exclusive job, with one A10 and no automatic retries. This review used local CPU fixtures and static inspection. Runtime cache accessibility and model behavior remain checks for any separately approved execution. Historical development exposure, paired clean/noisy views and unknown speaker overlap limit the experiment's scope.

Reviewed SHA256 bindings

- `alignment_protocol.md` `77c444bc7e864dbd4f9ff3ad03cb90628cb78971d48185f4b159d96d127422a0`
- `artifacts/alignment-scientific-decision.json` `461b85b15f4f3d6dddd52e2ab9da68e845b0ac0d30262138c84ebdcb30a92590`
- `prepare_alignment.py` `09a3e6be90b5832c1678dc6c338f613b342c429f8e58ac7a80524f69786e1061`
- `alignment_analysis.py` `010e77ea13e3e00fbb72aee67bae5996e4328f8e75c1aea9a5d91c0a79327dcf`
- `alignment_worker.py` `916828ee023104ab85851abbadb9b8fe7368e0f5d932df39467b3a2da1071b1f`
- `alignment_objective.py` `77b629093e1eb8666fbb7cf631ceaf75afeee02bbcfc6ed67fdebdf355fc4748`
- `alignment_runner.py` `2cb38bd6fe9b52e800a98bff77517ff8a62fa88d55e11f93c951d377bb32ea98`
- `../score.py` `e0734875a834647dd462fe05ba032c42362338aa8bd7b909c2471571bb8b01da`
