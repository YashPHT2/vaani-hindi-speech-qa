# Localization final prelaunch code/provenance review

Decision: **PASS for the prospectively declared user-reported-window sensitivity diagnostic**, pending root final freeze/reservation. The earlier input-path blocker is resolved honestly. This is not complete-phrase ablation or independent confirmation of full target extent. No GPU, network, model/tokenizer jobs, listening, agents, source edits or reservation/launch actions were performed. Only this review file was written.

## Capture branch and binding

Independently viewed the two preserved local screenshots. They show start3/end4seconds, an empty uncertainty input, placebo start8seconds and the unrelated-placebo checkbox checked. They do not show a complete-phrase checkbox state. The raw alternate capture preserves that field asnull, records the separate user reply0.1and screenshot/chat capture category, and binds the two image files plus prior listening import. This reviewer can verify displayed image values and file binding; the raw chat response is provenance supplied through the session/root, not reconstructed from an image that did not show it.

prepare_localization.py retains the strict original export branch requiring explicit complete-phrase confirmation. Its separate chat branch requires unknown/null checkbox, screenshot hashes, user-reported coordinates,prior target audibility and uncertainty agreement. The derived boundary and config both say human_reported_bounds and full_phrase_extent_verified=false. The runner retains separate strict/reported branches, rejects converting an unseen checkbox into true, verifies raw/derived/source/image/prior-listening hashes and ensures both selected1806recordings match the prior verified audibility entries. The worker emits the qualified reported-window interpretation and false full-extent flag. No fictitious export or complete-phrase confirmation was found.

All hashes in the draft source/provenance map match current bytes. Independently checked the preserved raw capture hash and derived-boundary hash. Pair,model/revision,actual inputs and fixed same-condition1868donor inputs equal the immutable previous omission configuration. The input is two acoustic versions of one historical source; no other listener items or fresh test are added.

## Masks, scoring and arithmetic

Reported phrase[3,4]±0.1produces target-window[2.9,4.1] and equal-duration placebo[8,9.2]. Rounded half-open sample bounds are[46400,65600]and[128000,147200],each19200samples; fade is80samples per edge. Bounds are within the13.68second record and disjoint. Existing inside-only raised-cosine/zero-plateau masking preserves all outside samples and duration, exports changed-waveform hashes and per-window energy/RMS, and introduces no global normalization/resampling. Equal duration does not imply equal removed energy,noise or speech content.

Re-read masking/scoring after the provenance patch. Correct next-token lexical index len(prefix)-1and separate EOS handling remain intact; no QA answer generation,adapter or training path exists. Complete tokenization is committed before acoustic encoding. LCP/LCS differencing preserves the empty-minus-region convention. The primary first-difference odds implementation uses exactly one shared-prefix decoder forward and the same final vocabulary distribution for both IDs; separate full-candidate first-token scores remain secondary. All32expected model forwards are explicitly counted:8encodes,16full-candidate decodes and8shared-prefix decodes. Both conditions retain original,reported-target-window-mask,placebo-mask and mismatch controls.

localization_analysis.py signs are correct: target_drop=S(original)−S(target_masked);placebo_drop=S(original)−S(placebo_masked);their difference equalsS(placebo_masked)−S(target_masked). Original-minus-mismatch is separate. It preserves summed/per-token candidate metrics and single-shared-prefix odds under distinct names,without relabeling secondary full-forward token differences as same-distribution odds. The prospectively declared primary measure remains full lexical+EOS summed preference; shared-prefix odds are an auxiliary readout. All metric signs and both conditions must remain reported rather than selecting the favorable one.

Analysis statically checks result/config/source hashes,forward counts,finite values,complete condition/control coverage,raw lexical sums/EOS reductions,mask audits and old candidate/prefix replication. It does not independently recompute every mean/span statistic or actual waveform mutation; a bounded postrun artifact review should still reconstruct these from archived tokens/masks. No current material arithmetic or launch-path bug was found.

Runner's exclusive local claim before spawn,source/provenance/audio checks,immutable old pair/input checks,bounded resources,zero automatic retries and exception cancellation remain sound for the scoped launch. Draft source hashes are review bindings; final immutable freeze and conservative reservation have not been performed by this reviewer.

## Controlling interpretation

The reported mask may contain only part of the phrase plus surrounding speech. Earlier predicted DTW labels are neither ground truth nor grounds to silently move the user window. A positive differential supports contribution of the declared waveform interval to this synthetic-deletion preference under the fixed intervention; a null effect cannot prove the phrase is unused. Whole contextual encoder changes,unequal candidate lengths,content/energy differences and zeroing noise in the noisy version remain confounds. No word-localization,complete-phrase necessity,population inference,QA gain,fallback benefit or new-training GO follows. The protocol's explicit capture qualification and config flags control over generic form instructions that describe a fully checked strict import.

## Reviewed SHA256 bindings

- `localization_worker.py`: `c27f8a6c1d983de1feb46a03f5df07d6d0937553d049ad5b9815d59902092ec1`
- `localization_runner.py`: `11d8186faf27d0ed2a358b38c40b079c25cc92994b06a8642c769c912240eb1b`
- `prepare_localization.py`: `6d538a4c268b9af3cf358f37fa8713ead192a3dcb1c982ed9e0cd9e30d8f4346`
- `localization_analysis.py`: `8af35da55851e997b0c50d4d6f79476c459fab6d2aef0f2e08ac7bb7fb27443b`
- `artifacts/localization-config-draft.json`: `78e1469395313b174b58efb8f2fc4b0cdcb353462c35369068b503fc4b600154`
- `artifacts/localization-boundaries-validated.json`: `1c6fa9966e45f62b49a81973c834129006628cdabf2eb5061b04a6165d3c3014`
- `localized_intervention_protocol.md`: `aa4803f0a686cd7bfa9a822dc6be04a8e35becfd1cda1dfc496ebda32a29e24b`
