# Localized waveform intervention: prospective protocol draft

Status: implementation preparation; no GPU launch. The user's latest assessment selects this experiment before broader
training. The old omission freeze and all its raw scores remain immutable.

### Prospective capture qualification

The user supplied screenshots showing3–4seconds and an unrelated placebo
starting8seconds, then explicitly supplied uncertainty0.1in chat. The screenshot
shows the placebo confirmation checked; the complete-phrase checkbox is not
visible. No new browser-export file was recovered and browser inspection tools
failed to initialize. Preserve the screenshot/chat capture and both image hashes;
do not create a fictitious form export or set the unseen checkbox true.

This branch is a **user-reported-window intervention**, with
full_phrase_extent_verified=false. The intervals are2.9–4.1seconds and8–9.2seconds,
each19,200samples at16kHz. Prior listening confirms the target is audible in
both versions. Exact complete-phrase extent remains uncertain; stored predicted
DTW labels differ and are not localization ground truth. Any measured effect
must be described as contribution of the declared interval, not complete phrase
ablation. The strict original complete-phrase form-import path stays separate.

## Question and constants

Does the interval containing प्रकाश प्रदूषण contribute more to frozen
Whisper's correct-versus-synthetic-deletion preference than an equal-duration,
listener-checked unrelated interval? One historical source fleurs-hi-1806,
clean/noisy views, pinned Whisper-small and original full hypotheses/donor1868.
No Qwen, adapter training, classifier, selector change, K expansion or fresh100.

The source is outcome-selected and repeated acoustic views are one independent
recording. Positive results indicate localized contribution under the declared
intervention, not isolated word representations or successful memory readout.

## Boundary verification before scoring

Use `localization_boundary_review.html` for reference-guided listening. The
prior2–3second annotation is unvalidated for exact phrase extent. Record phrase
start/end, uncertainty±u and explicit confirmation that the complete phrase is
inside the interval in both views. The primary target-mask interval expands
the annotation by u on both sides, clipped to recording duration. It therefore
may contain neighboring context. No later boundary search based on score gains.

The listener also checks a separate unrelated interval with exactly equal
duration. A default8second start is a proposal, not a verified placebo. Source
clip hashes and saved raw annotations must match the historical manifest.
`prepare_localization.py` preserves the raw JSON and binds derived validation,
rounding and boundaries in a draft before independent source review/freeze.

Target boundaries round to nearest16kHzsample; placebo start rounds and its
end=start+targetN, guaranteeing equal sample counts. Both intervals must fit,
not overlap, and exceed the combined edge-fade lengths. No source samples are
resampled, shifted, duration-normalized or globally amplitude-normalized.

## Four audio conditions per acoustic view

1. Original waveform unchanged.
2. Target interval masked to zero with5ms raised-cosine transitions inside it.
3. Placebo interval masked using the identical rule and equal sample count.
4. Original frozen mismatched donor1868 of the same acoustic condition/duration.

Assert samples outside each mask are bitwise unchanged. Save sample bounds,
float32 waveform hashes, interval RMS/removed energy and duration. These
diagnostics do not equate the phonetic content or energy of target/placebo;
masking artifacts and whole-recording alignment changes remain limitations.
Zero masking in noisy audio also suppresses noise inside that interval.

## Scoring and contrasts

Retain the original candidate lexical/EOS score definitions, Hindi prefix,
FP16/SDPA implementation and sum/per-token analyses. Persist pinned tokenizer
IDs and common-prefix/suffix masks before acoustic scoring. Candidate lengths
remain unequal,192 versus172lexicaltokens in the prior run. The deletion side
has an empty differing-token region; empty-sum conventions must stay explicit.

First-diverging-token odds will use ONE forward pass of the shared decoder
prefix and a single final logits distribution for both next-token IDs. Do not
reuse the previous separate-full-sequence-pass odds as the new primary odds.
The existing full-sequence scoring remains separate from that short-prefix
calculation; first-difference tokens may be byte fragments, not complete words.

For each metric M, define S_M as plus-minus preference and report:

    target_drop_M  = S_M(original) - S_M(target_masked)
    placebo_drop_M = S_M(original) - S_M(placebo_masked)
    localization_M = target_drop_M - placebo_drop_M
                   = S_M(placebo_masked) - S_M(target_masked).

Primary readout: summed lexical+EOS log-score preference. Per-token and shared
prefix odds are separately labeled diagnostic measures. Positive localization
means a larger target-mask loss for that declared comparison. Report both
conditions and all signs, not a winner selected across metrics. No population
significance or trainingGO from this one source. Original/donor score agreement
with old artifacts is a reproducibility check, not additional independent data.

## Candidate availability and next decision

Stored pilot1806noise has0validcandidates/56discarded/0addedmemoryvectors. This
holds for all intervals and has independent artifact verification. Clean has46
candidates with four selected; precise interval coverage will be recomputed
after the listening-defined bounds. Archived pilot aggregate has12/88empty
views over44historical sources; individual training failure IDs are not locally
exported and source-level failure overlap is unknown.

An alignment-independent candidate fallback is a prospective architecture
option, not an evaluated improvement. A localized positive result would motivate
a separate privileged existing-connector readout test with matched baselines
and wrong audio. A failed existing connector would not rule out an oracle-trained
readout. Do not bundle fallback construction, alignment training and new ranking.

## Resources and stopping

One A10, CPU2, RAM16GiB;600sfunction,300sstartup,120squeue, no automatic retries,
exclusive runID localized-omission-sensitivity-v1. Proposed reservation USD1,
previous conservative public-rate bound USD0.63168344; no funds reserved by
this draft. Check gross workspace metering and existing apps before launching,
preserve total USD30cap and USD3reserve. Stop after this one declared run and
independent integrity/interpretation review. Broad training and fresh100 stay held.
