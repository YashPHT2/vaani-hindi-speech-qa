# Token-limit diagnostic prelaunch review

Decision: PASS for the authorized single C-only historical diagnostic, conditional on the root binding these reviewed bytes and budget reservation in its prelaunch freeze. No launch, network, GPU, training or fresh-data access was performed by this reviewer. Only this review artifact was written.

The input is exactly equal, field for field and in original order, to all 24 C_correct_text rows in preserved headroom-result.json. It contains 12 historical source IDs with one clean and one noise view each; six old responses are length-capped. All use publisher text, genuine historical question and zero memory tokens. These paired text-identical conditions are correlated repetitions, not 24 independent passages.

The new worker pins the same Qwen checkpoint, FP16/SDPA backend, seed17, eval/inference mode, two CPU threads, same tokenizer, unmodified connector.pack_prompt and greedy decoding/EOS/pad arguments. It emits K=0 and loads no ASR or adapter. Its generate helper accepts only evidence, question and token cap. It calls pack_prompt with no answer and asserts labels=None; input answer aliases and old output strings are used only for records/comparison, not model conditioning. The sole prospective generation intervention is max_new_tokens=128 rather than48. A one-token question-only warmup matches the previous run. The previous teacher-forced NLL calls are omitted, but they had use_cache=False under inference mode and did not feed generation; their omission changes surrounding work/timing rather than the intended generation condition.

Prefix guard: for each previously capped response, decode and strip the first48 new generated IDs and compare with its preserved old decoded response. For each previously uncapped response, compare the full new decoded response with the old response. New token IDs are retained. The old run did not preserve token IDs, so this establishes decoded-text prefix equality only, not identical old tokenization. Mismatch IDs are reported and interpretation_allowed=false; no rerun path exists. All24 rows are retained even on a mismatch. Post-run interpretation must actually enforce that flag and report any mismatch without retry. This code reports rather than silently suppressing a mismatch.

Exclusive cloud directory gold-token-limit-dev24-v1 and local job/result guards prevent silent repeat; bounded A10 resources, no automatic retries, queue timeout and exception cancellation are present. New source/input hashes and the resource reservation still need the root's final immutable freeze; this review does not validate a not-yet-written freeze. Generation-only timing excludes model loading and must not be read as pipeline latency.

No material source/packing/matching blocker found. Recommend one bounded execution followed by retained-denominator assessment of actual128-token outputs, including persistent truncation/gibberish. Broad training remains held and fresh evaluation sealed.

Reviewed SHA256 values:

- `token_limit_worker.py`: `2e33b764ba65d8e5e204c0dfdec57cb26922a8fff0639d6dc103d18413731da2`
- `token_limit_runner.py`: `496bd222ba221bea7dc0085d8673b5659410c1358d5806ed149ee423118081ac`
- `connector.py`: `39803bc3e46f4db213a911dae6438a8eb8d908f95c2d2efc36238fedf24e68db`
- `artifacts/token-limit-input.json`: `d3c1127325076630d5e86b664296c6b553f81ded7316b25f5845d8d37ae53442`
- `artifacts/headroom-result.json`: `2d4f049ab05d9b659ca74a8bd431319bb9cfdedcad51c1d5d63f3d632700d1a4`
