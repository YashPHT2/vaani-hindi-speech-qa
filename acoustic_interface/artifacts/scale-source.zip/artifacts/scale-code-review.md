# Independent scalar-code prelaunch review

**PASS after one conservative-label merge fix.** Final freeze/reservation remain root-owned. No GPU,network,model/tokenizer execution,agents or source edits were performed. Only this review artifact was written. Reviewed worker/runner,preparator,analysis,reconciler,updated protocol and final draft; all draft source hashes match.

The only requested fix was an old-label conflict merge that flagged ambiguity but retained the independent correctness value. Changed lines now force correctness=false,ORthe unsupported flags,retain both originals and flag ambiguity. This matches the updated conservative reconciliation rule. New-case reconciler preserves both model reviews; strict analysis rejects every ambiguous supported-correct label without dropping any primary view. Both gate variants require no unsupported additions. No remaining material static blocker was found.

## Scalar path and target isolation

Only theta is an FP32Parameter; optimizer is Adam([theta]),lr0.1,default betas/epsilon,zero weight decay,no clipping. Alpha=exp(theta),clamped through logtheta after each update to[1/32,2]. Four fixed seed17+epoch shuffles over64views,loss/8 accumulation and eight groups per epoch give32updates. Final endpoint is used without dev selection. Finite losses,theta and gradients are required. Frozen Qwen forward remains differentiable during fitting; packing casts FP32memory to LMdtype without detaching alpha. Frozen model/adapter gradients must remain absent. No other learned parameter is optimized.

Each actual/donor memory is constructed,routed and detached once before scale evaluation. Stored CPUmatrix bytes are cloned/hashed and transferred unchanged for use; alpha is applied only after projection/gates. Thus selection and geometry cannot change with alpha. Training memories and wrong memories are not optimized. Returned checkpoint hashes,adapter full state,param-version checks and detached-memory hash checks support invariance; runtime artifacts must still demonstrate these assertions.

Generation packing has answer=None and never contains reference answers. First-target score uses the answer-free prefix's final logits; target token is token0of tokenizing the same first accepted answer+assistant end marker used by CEpacking. Gold token indexing is a scoring selection,not a prompt feature. NLL is a separate subsequent use_cache=False scoring forward; generation is greedy48/use_cache=True and receives no gold cache. Preflight scores are separately normalized log probabilities,not raw offsets.

## Inputs, gates and controls

Independently checked all88wave hashes,exact frozen available-cache bindings,32train/11primary/one illustrative source partitions,48baseline rows and24donor mappings. Training is64views; primary is22views;1806two views remain illustrative. Donors are same-condition,different training source,nearest absolute duration with decimal-ID ties. Complete valid donor encoder frames are linearly interpolated with align_corners=false to recipient frame count once; recipient DTWgeometry,U,masks,question and scaffold remain. Donor routing occurs once and may differ from actual routing. New fallback grids use unavailable zeroU; no privileged interval enters this experiment.

Preflight uses the declared four training sources,five fixed alphas,two views=40outputs. The source mean of per-view maximal logprob change and NFC/lowercase/whitespace-only answer variation implement the declared gate; punctuation is intentionally retained. It can pass on nonsense changes,which measures sensitivity only. Required missing cache or empty-after-fallback stops with incomplete gate; failed gate returns zero updates/no dev outputs. No cache regeneration,fresh ID or source replacement exists.

Conditional evaluation is five arms×22primary plus ten illustrative outputs. Baseline alpha-one/text answer+scaffold comparisons bind prior results; mismatch blocks utility success. Physically empty K0text uses the same prompt. Analysis independently recalculates preflight/source-level actual-versus-donor changes,retains22primary views and requires both conservative and strict gates. Missing new labels cannot yield a success calculation. NLL,norms and timings remain secondary.

## Execution and limits

Canonical JSON/input hashes and write_bytes avoid prior CRLFerrors. Runner claims an exclusive job before spawn,binds model/checkpoint/source/cache/wave metadata,checks bounded allocation and uses1800/300/120second limits,internal1740deadline,zero retries. No promoted/smoke checkpoint is loaded. Preserve partial artifacts on any failure and do not replace failed examples. Source grouping is not speaker separation; prior-dev exposure and model-authored/model-reviewed QA remain limitations. No success here establishes scale causality,generalization or authorization for alignment/fresh evaluation.

Final reviewed bindings:

- `scale_worker.py`: `87d15f52caacea42b6c7b0305be0ba06a095f6a7686a55801d6672e22499905c`
- `scale_runner.py`: `b2b111e0e6d7859b1552ee4dc0764a35f73fc7fd4437e9482afcd1c80a23378d`
- `prepare_scale.py`: `c487fbc800bddf13689eb12a88baf82b2c3cf934135c92c635f44f5d55f2cfe3`
- `scale_analysis.py`: `e94d14171a2d9e8f11461220aa8270d73f2b6d817e714e4823eed2a6f3197948`
- `reconcile_scale_labels.py`: `6a4d41c8ec901b75b4d5d5924b9cdba8abbad63755547e247465b3245c95b3b9`
- `scale_protocol.md`: `157065b41e4993d542dd4f82ef226ec263f04fc8a17f0763585e673adc748e29`
- `artifacts/scale-config-draft.json`: `0109bb3f4c8707fdfcd5c0f69e82f16517cac9b361334286051f4cc4cd01c10c`

Final changed-line acceptance: analysis also requires weight_invariance.detached_memory_bytes_unchanged=true; this matches the worker-returned field and only strengthens integrity gating.
