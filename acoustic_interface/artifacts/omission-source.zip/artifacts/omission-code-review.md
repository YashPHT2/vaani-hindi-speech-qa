# Bounded omission code/config prelaunch review

Decision: **PASS for the scoped synthetic-omission amendment**, pending the root's final prospective freeze and conservative reservation reconciliation. This is not a pass of the old literal-local-competitor gate. No GPU, network, listening, model execution, training or code edits were performed by this reviewer. Only this review artifact was written; offline hash/JSON/WAV-header bookkeeping checked input provenance without judging audio.

Read omission_worker.py, omission_runner.py, omission-config-draft.json and updated listening-imported.json. All draft source hashes match current bytes, including updated listening import and separate chat-confirmation artifact. Only the already human-verified1806clean/noisy views are selected; the later four-clip confirmation is not needed to admit this pair. Both have effective target verification, with the existing single-user reference-guided scope. No uncertain Rossby or manufactured year enters this diagnostic.

## Scoring and token boundaries

Next-token indexing is correct: decoder input is sequence[:-1], logits[t] predicts sequence[t+1], gathered targets are sequence[1:], and lexical scores start at len(prefix)-1. Exactly len(lexical) entries are lexical; logp[-1] is EOS. Forced language/task/start/no-timestamps prefix probabilities are excluded from reported lexical/EOS sums. Prefix and candidate encoding use the pinned Whisper-small tokenizer revision and the same Hindi transcription/no-timestamp prefix. There are no QA questions, answer labels, adapter calls, generation or optimization. Both candidates are intentionally teacher-forced score targets.

Lexical-only sum/mean and lexical+EOS sum/mean are separately exposed with counts, IDs and individual lexical token log probabilities. First-divergent-token scores address the next candidate token after the exact longest common token-ID prefix; their difference is a log-odds contrast under the common text history and same audio. The candidate lengths differ and this is not a calibrated correctness probability.

LCP/LCS region construction is internally consistent and prevents overlapping prefix/suffix matches. For an empty minus differing region, its sum is0 and mean isNone, with count0 explicitly recorded. It does not fabricate an omitted target token or assign suffix tokens to the deletion. The stored label says token differing region, not exact reference-character mask or acoustic timestamp. Boundary retokenization could make the plus region include adjacent material; inspect returned tokenization before calling it exact target-only logP. Actual-minus-silence/mismatch contrasts can be recomputed from all archived component preferences; the worker returns the necessary component scores rather than hiding unfavorable signs.

Pinned tokenization, complete prefix/candidate IDs and LCP/LCS boundaries are serialized to tokenization.json, hash-bound and volume.commit is called before acoustic encoding or scoring (indeed before model loading). Actual resolved IDs are runtime-pending; this static review cannot certify their expected span or lengths without observing that artifact. No scoring uses a post-outcome choice of tokenizer boundaries.

## Exact strings and input controls

The declared plus sentence matches the historical publisher reference. The minus sentence is exactly plus[:29]+plus[44:], deleting प्रकाश प्रदूषण plus its one trailing separator. Target-only character span is[29,43), deletion span[29,44), so the separator handling is explicitly declared rather than silently repaired. The negative is synthetic, not the observed repeated noisy ASR sentence or a phonetic alternative. The shared remaining context and unequal lengths are preserved.

Independently checked actual and donor raw file hashes against config and original historical-manifest rows. All four WAV files are mono16kHz16-bit PCM with218880samples, exactly13.68seconds. The donor is different historical source1868 in the same respective clean/noisy condition, with target phrase absent from its publisher text. It has a1.0duration ratio; no resampling is introduced. Only two actual condition views from one independent source are scored; the donor is a fixed control, not another recoverability sample.

Upload guards hash both actual/donor byte arrays locally, and worker verifies each again before parsing WAV headers and converting little-endian signed int16 to float32/32768. This preserves historical waveform scaling. Zero control uses zeros_like(actual) and goes through the same processor and acoustic encoder, so it is encoded same-duration silence, not encoder absence. Every control encodes once and scores both candidates on the same hidden states. Full donor audio changes all evidence; whole-sequence effects cannot establish target localization. The approximate clean2–3second human interval is not used for forced localization, and no noisy target interval is fabricated.

## Bounded execution and interpretation

Exclusive run directory and existing local job/result guards prevent silent repetition. The runner verifies final frozen source hashes and raw upload hashes, checks authorized ledger state/total cap, uses one A10, fixed resource bounds, zero retries, queue timeout and exception cancellation. Root still needs to create the final freeze and reconcile the cost reservation before launch; this report does not treat a draft or nominal reserve as measured billing. Token resolution and all three controls per condition must remain visible even on null/reversed results.

No material implementation bug found. Runtime acceptance should check six unique condition/control rows, matching tokenization hash/config/source/audio bindings, finite scores, exact lexical/EOS reductions and absence of training/fresh data. Signed actual-minus-control preferences support only exploratory frozen-decoder sensitivity to these synthetic unequal-length hypotheses. They do not unlock QA/adapter/selector training, fresh evaluation, a population claim or a conclusion that an encoder lacks the audible phrase.

## Reviewed SHA256 bindings

- `omission_worker.py`: `1861ba6861e7d32115b9c2b09156cbba7fd6a86e4156e4847334460894f9c48f`
- `omission_runner.py`: `8351b9a5179f3ce5327d8b15b2ab8c6e4a0fbd46be767a9a4e1eae65372dacaa`
- `artifacts/omission-config-draft.json`: `46f1c959e17f2cdbe1eb9d956cee2dd84b2a15a59cef44d8b5e975d647b04831`
- `artifacts/listening-imported.json`: `dc7117e8138c78ee01c83e1e45703067bf97ba0175cdfe7bd8ad91065780a3e3`
- `artifacts/listening-chat-confirmation.json`: `293e5ef9762fb57bb4160538951dab1a8a55195a997626ea72762cbb8a31ec09`
